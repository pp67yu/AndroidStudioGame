package com.example.gameapp;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.SystemClock;
import android.widget.Chronometer;

import androidx.annotation.Nullable;

public class BoundService extends Service {
    private static String LOG_TAG = "BoundService";
    private IBinder mBinder = new CustomBinder();
    private Chronometer chronometer;


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    public class CustomBinder extends Binder {
        //returns object of BoundService Class so that it can be accessed in all other public methods of this classes
        BoundService getService(){
            return BoundService.this;
        }
    }
    @Override
    public void onRebind(Intent intent) {
        super.onRebind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        chronometer.stop();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }
    public String getTimeStamp(){
        long elapsedMillsec = SystemClock.elapsedRealtime() - chronometer.getBase();
        int hours = (int)(elapsedMillsec/3600000);
        int minutes = (int)(elapsedMillsec - hours*3600000)/60000;
        int seconds = (int)(elapsedMillsec - hours*3600000-minutes*60000)/1000;
        return hours+":" +minutes +":" +seconds;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        chronometer = new Chronometer(this);
        chronometer.setBase(SystemClock.elapsedRealtime());
        chronometer.start();
    }
}
