package com.example.gameapp;

import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;

public class AnimationGun {
    public static void startAnimation(final ImageView img1, final ImageView img2){
        img2.setVisibility(View.VISIBLE);
        Animation alpha = new AlphaAnimation(0f, 1f);

        alpha.setDuration(300);
        alpha.setFillAfter(true);
        alpha.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                shotDisappear(img1);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                shotAnimationEnd(img1);
                GunAnimationEnd(img2);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        img2.startAnimation(alpha);
    }

    private static void GunAnimationEnd(final ImageView image) {
        Animation alpha = new AlphaAnimation(1f, 0f);

        alpha.setDuration(300);
        alpha.setFillAfter(true);
        alpha.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        image.startAnimation(alpha);
    }

    private static void shotDisappear(final ImageView image) {
        Animation alpha = new AlphaAnimation(1f, 0f);
        alpha.setDuration(300);
        alpha.setFillAfter(true);
        alpha.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        image.startAnimation(alpha);
    }

    private static void shotAnimationEnd(final ImageView image) {
        Animation alpha = new AlphaAnimation(0f, 1f);
        alpha.setDuration(300);
        alpha.setFillAfter(true);
        alpha.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        image.startAnimation(alpha);
    }
    }
